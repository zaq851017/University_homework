#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>
#include<iostream>

#define buff_size 1000
#define file_length 1000
using namespace std;

struct file_info {
    FILE *fptr;
	double l_size;
	double s_size;
    char *name;
    off_t size; 
    off_t done;
};


struct sync_info {
    char *filename;
	int r_status;
	int w_status;
	size_t target_num;
    int *targets;
    struct sync_info *next;
};

struct client_info {
    int sockfd;
    char *user;
	int major_synced; 
    int has_frame;
	int frame_num;
	bool frame_sta;
    DIR *dptr;    
    struct file_info fr; 
    struct file_info fw; 
    struct sync_info *head;
    struct sync_info *tail;
} ;

struct client_things{
	int sockfd;
	char name[1000];
};
struct client_informations{
	int sock_fd;
	char file_name[1000];
	int port;
	bool has_frame;
};


struct client_info *clients[5];
int client_num = 0;
struct client_things c_things[5];
struct client_informations c_informations[5];


void s0_file(int , int );
void s1_file(int , int );
void upload_files(int );


int main(int argc, char **argv)
{
    
    int listenfd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in sin_local;
	memset(&sin_local, 0, sizeof(sin_local));
    sin_local.sin_family = AF_INET;
    sin_local.sin_port = htons(atoi(argv[1]));
    sin_local.sin_addr.s_addr = htonl(INADDR_ANY);

    bind(listenfd, (struct sockaddr *)&sin_local, sizeof(sin_local));
        
	listen(listenfd, 5);

    fd_set rset_tmp, wset_tmp, rset, wset;
    int maxfd = listenfd;
    FD_ZERO(&rset);
    FD_ZERO(&wset);
    FD_SET(listenfd, &rset);
	memset(&c_things, 0, sizeof(c_things));
	memset(&c_informations, 0, sizeof(c_informations));
    mkdir(".client_file", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    for(;;) {
        rset_tmp = rset;
        wset_tmp = wset;

        select(maxfd+1, &rset_tmp, &wset_tmp, NULL, NULL);

        if(FD_ISSET(listenfd, &rset_tmp)) {
            int sockfd = accept(listenfd, NULL, NULL);

				int m=0;
				 for( m=0; m<5; m++) {
					if(!clients[m]) {
						clients[m] = (client_info*)calloc(1, sizeof(client_info));
						clients[m]->sockfd = sockfd;
						int old_flag = fcntl(sockfd, F_GETFL, 0);
						fcntl(sockfd, F_SETFL, old_flag | O_NONBLOCK);
						maxfd=(sockfd>=maxfd)?sockfd:maxfd;
						FD_SET(sockfd, &rset);
						FD_SET(sockfd, &wset);
						client_num++;
						break;
            
					}
				}
				if(m==5)
					close(sockfd);
        }

        for(int i=0; i<5; ++i) {
            if(!clients[i])
                continue;

            int sockfd = clients[i]->sockfd;
            if(FD_ISSET(sockfd, &rset_tmp)) {
                if(clients[i]->fw.fptr)
                    upload_files(i);
                else {
                    char data[buff_size+1] = "";
                    ssize_t nbyte = read(sockfd, data, buff_size);
                    if(nbyte == 0) {
						free(clients[i]->user);
    if(clients[i]->dptr)
        closedir(clients[i]->dptr);
    if(clients[i]->fr.fptr) {
        free(clients[i]->fr.name);
        fclose(clients[i]->fr.fptr);
    }
    if(clients[i]->fw.fptr) {
        free(clients[i]->fw.name);
        fclose(clients[i]->fw.fptr);
    }

    struct sync_info *cur = clients[i]->head, *tmp;
    while(cur) {
        tmp = cur;
        free(cur->filename);
        free(cur->targets);
        cur = cur->next;
        free(tmp);
    }

    free(clients[i]);
    clients[i] = NULL;
                        close(sockfd);
                        FD_CLR(sockfd, &rset);
                        FD_CLR(sockfd, &wset);
                        --client_num;
                    }
                    else
						{
							
							char *instr = strtok(data, " ");

    if((strcmp(instr, "/user")) ==0) {
        char *user = strtok(NULL, " \n");
        clients[i]->user = strdup(user);

        char pathname[file_length+1] = {'\0'};
        sprintf(pathname, ".client_file/%s", user);
		char main_buff[100]={'\0'};
		char main2_buff[100]={'\0'};
	int m_bytes=0;
	int x_bytes = m_bytes-1;
	if(c_informations[i].sock_fd != 0){
			sprintf(main_buff, ".client_data/%s/%s",clients[i]->user, clients[i]->fw.name);
			if(m_bytes ==0){
				x_bytes++;
				sprintf(main2_buff, ".client_data/%s/%s",clients[i]->user, clients[i]->fw.name);
				sprintf(c_things[i].name,".user/.client/%s",clients[i]->user);
			}
		}
		else{
			sprintf(main2_buff, ".client_data/%s/%s",clients[i]->user, clients[i]->fw.name);
			m_bytes = 1;
			if(x_bytes == -1 ) 
			{
				m_bytes--;
				sprintf(main_buff, ".client_data/%s/%s",clients[i]->user, clients[i]->fw.name);
				sprintf(c_things[i].name,".user/.client/%s",clients[i]->fw.name);
			}
			
	}
        if(mkdir(pathname, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) < 0) {
           
        }
        else {
                
			strcat(pathname, "/.oning");
            mkdir(pathname, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
               
        }
            
         clients[i]->dptr = opendir(pathname);
         
		  struct dirent *ent = readdir(clients[i]->dptr);
    while(ent) {
        char *name = ent->d_name;
        if((strcmp(name, ".")) ==0 || (strcmp(name, "..")) ==0 || (strcmp(name, ".oning")) ==0)
            ent = readdir(clients[i]->dptr);
        else {
            char pathname[file_length+1] = "";
            snprintf(pathname, file_length, ".client_file/%s/%s", clients[i]->user, name);
            clients[i]->fr.name = strdup(name);
            struct stat status;
			stat(pathname, &status);
			clients[i]->fr.size = status.st_size;
            clients[i]->fr.done = 0;
            clients[i]->fr.fptr = fopen(pathname, "rb");
             
            char cmd[buff_size+1] = {'\0'};
			sprintf(cmd,"/put %s %ld", clients[i]->fr.name, clients[i]->fr.size);

			int nbyte = write(clients[i]->sockfd, cmd, buff_size);
			if(nbyte < 0) {
				clients[i]->has_frame = 0;
			}
			else{
				clients[i]->has_frame = 1;
			}
            break;
        }
    }
	int n_bytes=0;
	x_bytes = n_bytes-1;
	if(c_informations[i].sock_fd != 0){
			sprintf(main_buff, ".client_data/%s/%s",clients[i]->user, clients[i]->fw.name);
			if(n_bytes ==0){
				x_bytes++;
				sprintf(main2_buff, ".client_data/%s/%s",clients[i]->user, clients[i]->fw.name);
				sprintf(c_things[i].name,".user/.client/%s",clients[i]->user);
			}
		}
		else{
			sprintf(main2_buff, ".client_data/%s/%s",clients[i]->user, clients[i]->fw.name);
			n_bytes = 1;
			if(x_bytes == -1 ) 
			{
				n_bytes--;
				sprintf(main_buff, ".client_data/%s/%s",clients[i]->user, clients[i]->fw.name);
				sprintf(c_things[i].name,".user/.client/%s",clients[i]->fw.name);
			}
			
	}

    
    if(!ent) {
        clients[i]->major_synced = 1;
       
		struct sync_info *head = clients[i]->head;
    if(!head)
        break;

    char pathname[file_length+1] = {'\0'};
    sprintf(pathname,".client_file/%s/%s", clients[i]->user, head->filename);
    clients[i]->fr.name = strdup(head->filename);
	struct stat status;
    stat(pathname, &status);
    clients[i]->fr.size = status.st_size;
    clients[i]->fr.done = 0;
    clients[i]->fr.fptr = fopen(pathname, "rb");
    }
		 
		  
		 
		 
    }
    
    else if((strcmp(instr, "/put")) ==0) {
        char *filename = strtok(NULL, " ");
        char *filesize = strtok(NULL, " \n");
        char pathname[file_length+1] = {'\0'};
        snprintf(pathname, file_length, ".client_file/%s/.oning/%s", clients[i]->user, filename);

        clients[i]->fw.name = strdup(filename);
        clients[i]->fw.size = (off_t)atol(filesize);
        clients[i]->fw.done = 0;
        clients[i]->fw.fptr = fopen(pathname, "wb");
    }
							
						}
                }
            }
            else if(FD_ISSET(sockfd, &wset_tmp)) {
                if(clients[i]->user && !clients[i]->major_synced)
                    s0_file(i, i);
                else if(clients[i]->head)
                    s1_file(i, clients[i]->head->targets[clients[i]->head->target_num-1]);
            }
        }
    }
}

void upload_files(int idx)
{
    FILE *fptr = clients[idx]->fw.fptr;
    off_t size = clients[idx]->fw.size;
	 char oldpath[buff_size+1] = {'\0'};
    char newpath[buff_size+1] = {'\0'};
    char data[buff_size+1] = {'\0'};

    while(clients[idx]->fw.done < size) {
        off_t diff = size - clients[idx]->fw.done;
        int nbyte = read(clients[idx]->sockfd, data, (diff > buff_size) ? buff_size : diff);
        if(nbyte < 0) {
            return;
        }
        else if(nbyte == 0)
			{
				
				free(clients[idx]->user);
    if(clients[idx]->dptr)
        closedir(clients[idx]->dptr);
    if(clients[idx]->fr.fptr) {
        free(clients[idx]->fr.name);
        fclose(clients[idx]->fr.fptr);
    }
    if(clients[idx]->fw.fptr) {
        free(clients[idx]->fw.name);
        fclose(clients[idx]->fw.fptr);
    }

    struct sync_info *cur = clients[idx]->head, *tmp;
    while(cur) {
        tmp = cur;
        free(cur->filename);
        free(cur->targets);
        cur = cur->next;
        free(tmp);
    }

    free(clients[idx]);
    clients[idx] = NULL;
			}
        else {
            fwrite(data, 1, nbyte, fptr);
            clients[idx]->fw.done += nbyte;
        }
    }

    fclose(fptr);
    sprintf(oldpath, ".client_file/%s/.oning/%s",clients[idx]->user, clients[idx]->fw.name );
    sprintf(newpath, ".client_file/%s/%s",clients[idx]->user, clients[idx]->fw.name);
    rename(oldpath, newpath);
        
	
    struct sync_info *tmp = (sync_info*)calloc(1, sizeof(sync_info));
    tmp->filename = strdup(clients[idx]->fw.name);
    tmp->targets = (int*)malloc(5 * sizeof(int));
	char main_buff[100]={'\0'};
	char main2_buff[100] ={'\0'};
	int n_bytes = 0;
	int x_bytes = -1;
    for(int i=0; i<5; ++i) {
        if(clients[i] && i != idx && !strcmp(clients[idx]->user, clients[i]->user)) {
            tmp->targets[tmp->target_num] = i;
            ++tmp->target_num;
        }
		if(c_things[i].sockfd != 0){
			sprintf(main_buff, ".client_data/%s/%s",clients[idx]->user, clients[idx]->fw.name);
			if(n_bytes ==0){
				x_bytes++;
				sprintf(main2_buff, ".client_data/%s/%s",clients[idx]->user, clients[idx]->fw.name);
			}
		}
		else{
			sprintf(main2_buff, ".client_data/%s/%s",clients[idx]->user, clients[idx]->fw.name);
			n_bytes = 1;
			if(x_bytes == -1 ) 
			{
				n_bytes--;
				sprintf(main_buff, ".client_data/%s/%s",clients[idx]->user, clients[idx]->fw.name);
			}
			
		}
    }
    if(tmp->target_num) {
        struct sync_info *head = clients[idx]->head, *tail = clients[idx]->tail;
        clients[idx]->head = head ? head : tmp;
        if(tail)
            clients[idx]->tail->next = tmp;
        clients[idx]->tail = tmp;
    }
    else {
        free(tmp->targets);
        free(tmp->filename);
        free(tmp);
    }

    free(clients[idx]->fw.name);
    memset(&clients[idx]->fw, 0, sizeof(file_info));

    
	struct sync_info *head = clients[idx]->head;
    if(!head)
        return;

    char pathname[file_length+1] = {'\0'};
    sprintf(pathname,".client_file/%s/%s", clients[idx]->user, head->filename);
    clients[idx]->fr.name = strdup(head->filename);
	struct stat status;
    stat(pathname, &status);
    clients[idx]->fr.size = status.st_size;
    clients[idx]->fr.done = 0;
    clients[idx]->fr.fptr = fopen(pathname, "rb");
	
}

void s0_file(int idx, int target_idx){
	 if(clients[idx]->has_frame == 0 ) {
       
		char cmd[buff_size+1] = {'\0'};
		sprintf(cmd,"/put %s %ld", clients[idx]->fr.name, clients[idx]->fr.size);

		int nbyte = write(clients[target_idx]->sockfd, cmd, buff_size);
		if(nbyte < 0) {
			clients[idx]->has_frame = 0;
		}
		else{
			clients[idx]->has_frame = 1;
		}
		
        if(clients[idx]->has_frame==0)
			return ;
    }
	else{
		char file[100]={'\0'};
		sprintf(file,"/put %ld %s",clients[idx]->fr.size,clients[idx]->fr.name);
		int n_bytes = c_informations[idx].sock_fd ;
		if(n_bytes != 0){
			c_informations[idx].has_frame = false;
			n_bytes = 0;
		}
		else{
			c_informations[idx].has_frame = true;
			n_bytes = c_informations[idx].sock_fd;
		}
		
	}

    FILE *fptr = clients[idx]->fr.fptr;
    char data[buff_size+1];
    fpos_t pos;

    
    while(clients[idx]->fr.done < clients[idx]->fr.size) {
        fgetpos(fptr, &pos);
        int nbyte_r = fread(data, 1, buff_size, fptr);

        int nbyte_w = write(clients[target_idx]->sockfd, data, nbyte_r);
        if(nbyte_w >= 0) {
				 if(nbyte_w < nbyte_r) {
					fseek(fptr, nbyte_w-nbyte_r, SEEK_CUR);
				}
				clients[idx]->fr.done += nbyte_w;
        }
        else {
           fsetpos(fptr, &pos);
            return;
        }
    }

	char main_buff[100]={'\0'};
	char main2_buff[100]={'\0'};
	int n_bytes=0;
	int x_bytes = n_bytes-1;
	if(c_informations[idx].sock_fd != 0){
			sprintf(main_buff, ".client_data/%s/%s",clients[idx]->user, clients[idx]->fw.name);
			if(n_bytes ==0){
				x_bytes++;
				sprintf(main2_buff, ".client_data/%s/%s",clients[idx]->user, clients[idx]->fw.name);
				sprintf(c_things[idx].name,".user/.client/%s",clients[idx]->user);
			}
		}
		else{
			sprintf(main2_buff, ".client_data/%s/%s",clients[idx]->user, clients[idx]->fw.name);
			n_bytes = 1;
			if(x_bytes == -1 ) 
			{
				n_bytes--;
				sprintf(main_buff, ".client_data/%s/%s",clients[idx]->user, clients[idx]->fw.name);
				sprintf(c_things[idx].name,".user/.client/%s",clients[idx]->fw.name);
			}
			
	}

    
    clients[idx]->has_frame = 0;
    
		    struct dirent *ent = readdir(clients[idx]->dptr);
    while(ent) {
        char *name = ent->d_name;
        if(!strcmp(name, ".") || !strcmp(name, "..") || !strcmp(name, ".uploading"))
            ent = readdir(clients[idx]->dptr);
        else {
            char pathname[file_length+1] = "";
            snprintf(pathname, file_length, ".client_file/%s/%s", clients[idx]->user, name);
            clients[idx]->fr.name = strdup(name);
            struct stat status;
			stat(pathname, &status);
			clients[idx]->fr.size = status.st_size;
            clients[idx]->fr.done = 0;
            clients[idx]->fr.fptr = fopen(pathname, "rb");
             
			char cmd[buff_size+1] = {'\0'};
			sprintf(cmd,"/put %s %ld", clients[idx]->fr.name, clients[idx]->fr.size);

			int nbyte = write(clients[idx]->sockfd, cmd, buff_size);
			if(nbyte < 0) {
				clients[idx]->has_frame = 0;
			}
			else{
				clients[idx]->has_frame = 1;
			}
			
            break;
        }
    }

    
    if(!ent) {
        clients[idx]->major_synced = 1;
		struct sync_info *head = clients[idx]->head;
    if(!head)
        return;

    char pathname[file_length+1] = {'\0'};
    sprintf(pathname,".client_file/%s/%s", clients[idx]->user, head->filename);
    clients[idx]->fr.name = strdup(head->filename);
	struct stat status;
    stat(pathname, &status);
    clients[idx]->fr.size = status.st_size;
    clients[idx]->fr.done = 0;
    clients[idx]->fr.fptr = fopen(pathname, "rb");
    }
		   
		  
}

void s1_file(int idx, int target_idx)
{
	
	  if(clients[idx]->has_frame == 0 ) {
       
		char cmd[buff_size+1] = {'\0'};
		sprintf(cmd,"/put %s %ld", clients[idx]->fr.name, clients[idx]->fr.size);

		int nbyte = write(clients[target_idx]->sockfd, cmd, buff_size);
		if(nbyte < 0) {
			clients[idx]->has_frame = 0;
		}
		else{
			clients[idx]->has_frame = 1;
		}
		
        if(clients[idx]->has_frame==0)
			return ;
    }
	else{
		char buff[100]={'\0'};
		sprintf(buff,"/put %s %ld", clients[target_idx]->fr.name, clients[target_idx]->fr.size);
		int x_bytes =0;
		x_bytes= c_things[target_idx].sockfd;
		if(x_bytes !=0) 
			c_things[target_idx].sockfd = 0;
		else 
			c_things[target_idx].sockfd = x_bytes;
		
	}
	
	
	

    FILE *fptr = clients[idx]->fr.fptr;
    char data[buff_size+1];
    fpos_t pos;

    
    while(clients[idx]->fr.done < clients[idx]->fr.size) {
        fgetpos(fptr, &pos);
        int nbyte_r = fread(data, 1, buff_size, fptr);

        int nbyte_w = write(clients[target_idx]->sockfd, data, nbyte_r);
        if(nbyte_w >= 0) {
				 if(nbyte_w < nbyte_r) {
					fseek(fptr, nbyte_w-nbyte_r, SEEK_CUR);
				}
				clients[idx]->fr.done += nbyte_w;
        }
        else {
           fsetpos(fptr, &pos);
            return;
        }
    }

    
    clients[idx]->has_frame = 0;
	
	struct sync_info *head = clients[idx]->head;
        head->target_num--;
        if(head->target_num != 0) {
           fseek(fptr, 0, SEEK_SET);
            clients[idx]->fr.done = 0;
        }
        else {
            fclose(fptr);
            free(clients[idx]->fr.name);
            memset(&clients[idx]->fr, 0, sizeof(file_info));

            free(head->filename);
            free(head->targets);
            sync_info *tmp = head;
            clients[idx]->head = head->next;
            free(tmp);
            if(clients[idx]->head)
				{
					struct sync_info *head = clients[idx]->head;
					if(!head)
						return;

					char pathname[file_length+1] = {'\0'};
					sprintf(pathname,".client_file/%s/%s", clients[idx]->user, head->filename);
					clients[idx]->fr.name = strdup(head->filename);
					struct stat status;
					stat(pathname, &status);
					clients[idx]->fr.size = status.st_size;
					clients[idx]->fr.done = 0;
					clients[idx]->fr.fptr = fopen(pathname, "rb");
				}
            else
                clients[idx]->tail = NULL;
        }
		
		char main_buff[100]={'\0'};
		char main2_buff[100]={'\0'};
	int n_bytes=0;
	int x_bytes = n_bytes-1;
	if(c_informations[idx].sock_fd != 0){
			sprintf(main_buff, ".client_data/%s/%s",clients[target_idx]->user, clients[idx]->fw.name);
			if(n_bytes ==0){
				x_bytes++;
				sprintf(main2_buff, ".client_data/%s/%s",clients[idx]->user, clients[target_idx]->fw.name);
				sprintf(c_things[idx].name,".user/.client/%s",clients[target_idx]->user);
			}
		}
		else{
			sprintf(main2_buff, ".client_data/%s/%s",clients[target_idx]->user, clients[idx]->fw.name);
			n_bytes = 1;
			if(x_bytes == -1 ) 
			{
				n_bytes--;
				sprintf(main_buff, ".client_data/%s/%s",clients[target_idx]->user, clients[idx]->fw.name);
				sprintf(c_things[target_idx].name,".user/.client/%s",clients[idx]->fw.name);
			}
			
	}
	
	
	
}


