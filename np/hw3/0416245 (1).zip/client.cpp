#include<iostream>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <fcntl.h>
#include <sys/stat.h>

#define buff_size 1000
using namespace std;


void upload_file(int sockfd, const char *filename, double filesize)
{
	int data_sent = 0;
    char data[buff_size+1];
	cout<<"Uploading file : "<<filename<<"\n";
    FILE *fptr = fopen(filename, "rb");
	cout<<"[";
    while(data_sent < filesize) {
        int nbyte = fread(data, 1, buff_size, fptr);
       
		 int written = 0;
		while(written < nbyte ) {
			int rnbyte = write(sockfd, data+written, nbyte-written);
			written += rnbyte;
		}
        data_sent = data_sent+ nbyte;
		cout<<"#";
    }
	cout<<"]\n";
	cout<<"Upload "<<filename<<" complete!\n";
    fclose(fptr);
}

void download_file(int sockfd, const char *filename, double filesize)
{
	char data[buff_size+1];
	int data_recv = 0;
	cout<<"Downloading file : "<<filename<<"\n";
    FILE *fptr = fopen(filename, "wb");
	cout<<"[";
    while(data_recv < filesize) {
        off_t diff = filesize - data_recv;
        ssize_t nbyte = read(sockfd, data, (diff > buff_size) ? buff_size : diff);
        fwrite(data, 1, nbyte, fptr);
        data_recv =data_recv + nbyte;
		cout<<"#";
        
    }
	cout<<"]\n";
	cout<<"Download "<<filename<<" complete!\n";
    fclose(fptr);
}




int main(int argc, char **argv)
{
   
    int connfd = socket(AF_INET, SOCK_STREAM, 0);
  
    struct sockaddr_in sa ;
	memset(&sa, 0, sizeof(sa));
    sa.sin_family = AF_INET;
    sa.sin_port = htons(atoi(argv[2]));
    inet_pton(AF_INET, argv[1], &sa.sin_addr);
     
    connect(connfd, (struct sockaddr *)&sa, sizeof(sa)) ;
      
    printf("Welcome to the dropbox-like server! : %s\n", argv[3]);
    
	char data[buff_size+1];
    sprintf(data,"/user %s", argv[3]);

    write(connfd, data, buff_size);
    fd_set rset;
    int maxfd = connfd;

    for(;;) {
        FD_ZERO(&rset);
        FD_SET(0, &rset);
        FD_SET(connfd, &rset);

        select(maxfd+1, &rset, NULL, NULL, NULL);
        //user input command 
        if(FD_ISSET(0, &rset)) {
            fgets(data, sizeof(data), stdin);
            data[strcspn(data, "\n")] = '\0';
            //handle_cmd(connfd, data);
			char *cmd_tmp = strdup(data);
			char *instr = strtok(cmd_tmp, " \n");
    
			if((strcmp(instr, "/put")) ==0 ) {
			char *filename = strtok(NULL, "\n");
			struct stat status;
			stat(filename, &status);
         
			size_t cmdlen = strlen(data);
			sprintf(data+cmdlen, " %ld", status.st_size);
			write(connfd, data, buff_size);
			upload_file(connfd, filename, status.st_size);
		}
		else if((strcmp(instr, "/sleep")) ==0) {
			int sec = atoi(strtok(NULL, "\n"));
			cout<<"Client starts to sleep\n";
			for(int i=1;i<=sec;i++){
				cout<<"Sleep "<<i;
				sleep(1);
			}
			cout<<"Client wakes up\n";
		}
		else if((strcmp(instr, "/exit")) ==0) {
			close(connfd);
			exit(0);
		}
			
      }
        //command from server 
        if(FD_ISSET(connfd, &rset)) {
            int nbyte = read(connfd, data, buff_size);
           
            if(nbyte == 0) {
                close(connfd);
				cout<<"Server is closed.\n";
                return 0;
            }
            else {
                char *instr = strtok(data, " \n");
                if((strcmp(instr, "/put")) == 0 ) {
                    char *filename = strtok(NULL, " ");
                    double filesize = atof(strtok(NULL, "\n"));
                    download_file(connfd, filename, filesize);
                }
            }
        }
    }
	
    return 0;
}
