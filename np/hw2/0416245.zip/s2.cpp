#include <sys/types.h> 
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <signal.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <iostream>
#define MAXLINE 996
using namespace std;

struct packet{
	int  index;
	char content[MAXLINE];
}__attribute__((packed));;

void file_cli(FILE*, int, const struct sockaddr*, socklen_t, char *);


int main(int argc, char **argv) {
	int                 sockfd;
	struct sockaddr_in  servaddr;

	if (argc != 4){
		printf("Error: Wrong format.\n");
		return 0;
	}

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons( atoi(argv[2]) );
	inet_pton(AF_INET, argv[1], &servaddr.sin_addr);
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	file_cli(stdin, sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr), argv[3]);
	exit(0);
}

void file_cli(FILE *fp, int sockfd, const struct sockaddr* servaddr, socklen_t servlen, char* filename){
	int  			n, m, num = 1, recvnum;
	struct packet	p;
	struct timeval	tv;
	p.index = -1;
	bzero(p.content, MAXLINE);
	tv.tv_sec = 0;
	tv.tv_usec = 50000;// = 0.05sec
	setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	int f_len = 0;
	FILE *in = fopen(filename, "r");
	while(1 ){
		p.index = num;
		//read file_name
		if(p.index==1){
			for(int i=0;i<=strlen(filename);i++){
				p.content[i] = filename[i];
			}
			f_len = strlen(filename);
			sendto(sockfd , &p , f_len+4 , 0 , servaddr , servlen);
			printf("Read:%4d  %s\n",num, p.content);
		}
		

		else{
			n= fread(p.content,1,MAXLINE,in);
			if(n<=0) break;
			if( sendto(sockfd, &p, n+4, 0, servaddr, servlen) < 0 ){
				printf("ERROR: Failed to send file.\n"); break;
			}
			printf("READ:%4d (%d)\n", num, n);

		}
		
		//wait ack
		while(1){
			m = recvfrom(sockfd, &recvnum, 4, 0, NULL, NULL);
			if(m < 0){
				if(errno == EWOULDBLOCK){
					if(num==1) sendto(sockfd , &p , f_len+4 , 0 , servaddr , servlen);
					else sendto(sockfd, &p, n+4, 0, servaddr, servlen);
					printf("REPEAT: %d\n", p.index);
				}
			} else {
				if(recvnum == num) break;
			}
		}
		bzero(p.content, MAXLINE);
		num++;
	}
	p.index = 0;
	bzero(p.content, MAXLINE);
	sendto(sockfd, &p,4, 0, servaddr, servlen);
	printf("DONE\n");
	fclose(in);
	close(sockfd);
	return;
}

