#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <unistd.h>
#include <signal.h>
#include <string>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#define MAXLINE 996
#define LISTENQ 5
using namespace std;

struct packet{
	int  index;
	char content[MAXLINE];
}__attribute__((packed));;
void file_serv(int, struct sockaddr*, socklen_t);

int main(int argc, char**argv){
	int 				sockfd;
	struct sockaddr_in  servaddr, cliaddr;
	
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons( atoi(argv[1]) );

	bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr));

	while(1){
		file_serv(sockfd, (struct sockaddr*)&cliaddr, sizeof(cliaddr));	
	}
	
}

void file_serv(int sockfd, struct sockaddr* cliaddr, socklen_t clilen){
	int				n, num = 1;
	struct packet 	p;
	p.index = -1;
	int open=0;
	bzero(p.content, MAXLINE);
	FILE *out;
	while(1){
		//recv file
		cout<<"Before recv\n";
		n = recvfrom(sockfd, &p, MAXLINE+4, 0, cliaddr, &clilen);
		cout<<"after recv\n";
		if( p.index == 0 ) {
		sendto(sockfd, &p.index, 4, 0, cliaddr, clilen);
		break;	
		}
		else if(p.index ==1 && p.index==num){
			printf("Write: %4d %s\n",num,p.content);
			out=fopen(p.content,"w");
			open = 1;
			num++;
		}
		else if(p.index!=1 && p.index == num ){
			//write file
			printf("WRITE:%4d (%d)\n", num, n-4);
			fwrite(p.content, 1, n-4, out);
			num++;
		} 
		else printf("REPEAT: %d\n", p.index);
		sendto(sockfd, &p.index, 4, 0, cliaddr, clilen);
		bzero(p.content, MAXLINE);
	}
		

	//if(open==1){
		fclose(out);
		printf("DONE\n");
		open = 0;
	//}
	
}
