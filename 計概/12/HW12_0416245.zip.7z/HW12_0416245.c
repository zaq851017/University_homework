#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct file{
char name[30];
int name_num;
char date[30];
int date_num;
int dense;
char unit[30];
int unit_num;
};
struct file data[1001];

int compare(const void *a,const void *b){
const struct file *a1=a,*b1=b;
int r;
r=strcmp(a1->name,b1->name);
return r;//1,0,-1
}

int main(){
int i=0,digits=0,x=0;
char ch='0';
FILE *fp,*output,*outputb;
data[i].date_num=digits;
fp=fopen("PM2.5.csv","r");
output=fopen("outcomeSingle.csv", "w");
outputb=fopen("outcomeBinary.bin", "wb");
if(fp==NULL){
printf("FILE can't open. \n");
exit(EXIT_FAILURE);
}
else{
while(i<1000){
if(x==0){
while(fscanf(fp,"%c",&ch) && ch!='\n'){ x=1;}
}
else {
 digits=0;

while(ch!=','){
fscanf(fp,"%c",&ch);
data[i].name[digits]=ch;
digits++;
}
data[i].name_num=digits;

digits=0;
ch='0';

while(ch!=','){
fscanf(fp,"%c",&ch);
data[i].date[digits]=ch;
digits++;
}
data[i].date_num=digits;
fscanf(fp,"%d",&data[i].dense);

fscanf(fp,"%c",&ch);//read comma
data[i].unit[0]=ch;//unit[0]=comma
digits=1;

while(ch!='\n'){
fscanf(fp,"%c",&ch);
data[i].unit[digits]=ch;
digits++;
}
data[i].unit_num=digits;

i++;//return while
}
}

qsort(data,1000,sizeof(data[0]),compare);
fprintf(output,"Site Name, MonitorMate, Concentration, Item Unit\n");
fprintf(outputb,"Site Name, MonitorMate, Concentration, Item Unit\n");

i=0;//start to print to the output

while(i<1000){
   for(digits=0;digits<data[i].name_num;digits++){
    fprintf(output,"%c",data[i].name[digits]);
    fprintf(outputb,"%c",data[i].name[digits]);
            }

    for(digits=0;digits<data[i].date_num;digits++){
    fprintf(output,"%c",data[i].date[digits]);
    fprintf(outputb,"%c",data[i].date[digits]);
        }

    fprintf(output,"%d",data[i].dense);
    fprintf(outputb,"%d",data[i].dense);

    for(digits=0;digits<data[i].unit_num;digits++){
    fprintf(output,"%c",data[i].unit[digits]);
    fprintf(outputb,"%c",data[i].unit[digits]);
            }
            i++;
}
fclose(fp);
fclose(output);
fclose(outputb);
return 0;
}

}
