#include<iostream>
#include<string>
#include<vector>
#include<string.h>
#include<fstream>
#include <sstream>
#include <algorithm>
#include<math.h>
#include <time.h>
using namespace std;
double pr_a=0.0;
double pr_b=0.0;
double pr_c=0.0;
double good_a=0.0;
double good_b=0.0;
double good_c=0.0;
double re_a=0.0;
double re_b=0.0;
double re_c=0.0;
vector <double> c_a;
//c_a.clear();
vector <double>  c_b;
//c_b.clear();
vector <double>  c_c;
//c_c.clear();

vector <double>  p_a;
//p_a.clear();
vector <double>  p_b;
//p_b.clear();
vector <double>  p_c;
//p_c.clear();

vector <double>  t_a;

struct flower{
	double se_length;
	double se_width;
	double pe_length;
	double pe_width;
	string kind;
	int order;
};
bool compare(const flower &f1,const flower &f2){
	return (f1.order < f2.order);
}

class node{
	public:
	vector<flower> set;
	node(){}
	node(vector<flower> Data){
        set=Data;
    }
    node(node* b){
        set=b->set;
    }
	node *left;
	node *right;
	node *parent;
	string features;
	double bound;

	vector<flower> findData(){
        return set;
    }

	int Size(){
        return set.size();
    }
	node* operator=(node* b){
		node* r=new node(b->set);
		return r;
	}
};


class Tree{
	public:
		node* root;
		void Insert(node *b){
			root = b;
			root->left=NULL;
			root->right=NULL;
		}
		void Insert(node* current , node* l,node* r,int i,double b){
		    l->parent=current;
		    l->left=NULL;
		    l->right=NULL;
		    r->left=NULL;
		    r->right=NULL;
		    r->parent=current;
			current->left=l;
			current->right=r;
			current->bound=b;
			if(i==1){
				current->features="se_length";
			}
			else if(i==2){
				current->features="se_width";
			}
			else if(i==3){
				current->features="pe_length";
			}
			else if(i==4){
				current->features="pe_width";
			}

		}



};


void countbound(vector<flower> cal,vector<double> &a,int comp){
	 struct flower tempv;
	 a.clear();
	for(int j=0;j<(cal.size()-1);j++)
			for(int m=0;m<(cal.size()-1);m++)
			{
				if(comp ==1 && cal[m].se_length>=cal[m+1].se_length ){
					tempv=cal[m];
					cal[m]=cal[m+1];
					cal[m+1]=tempv;
				}
				else if(comp ==2 && cal[m].se_width>=cal[m+1].se_width ){
					tempv=cal[m];
					cal[m]=cal[m+1];
					cal[m+1]=tempv;
				}
				else if(comp ==3 && cal[m].pe_length>=cal[m+1].pe_length ){
					tempv=cal[m];
					cal[m]=cal[m+1];
					cal[m+1]=tempv;
				}
				else if(comp ==4 && cal[m].pe_width>=cal[m+1].pe_width ){
					tempv=cal[m];
					cal[m]=cal[m+1];
					cal[m+1]=tempv;
				}
			}
		//int a[150]={0};
		//int change=0;
		int k=0;
		double tn=0;
		for(int j=0;j<(cal.size()-1);j++){
			if(comp == 1 && cal[j].kind != cal[j+1].kind){
				tn=(cal[j].se_length+cal[j+1].se_length)/2.0;
				a.push_back(tn);
				k++;
			}
			else if(comp == 2 && cal[j].kind != cal[j+1].kind){
				tn=(cal[j].se_width+cal[j+1].se_width)/2.0;
				a.push_back(tn);
				k++;
			}
			else if(comp == 3 && cal[j].kind != cal[j+1].kind){
				tn=(cal[j].pe_length+cal[j+1].pe_length)/2.0;
				a.push_back(tn);
				k++;
			}
			else if(comp == 4 && cal[j].kind != cal[j+1].kind){
				tn=(cal[j].pe_width+cal[j+1].pe_width)/2.0;
				a.push_back(tn);
				k++;
			}
		}
		/*for(int i=0;i<a.size();i++)
			cout<<a[i] <<"\n";
		system("pause")	;*/

}


double INFO(double bound,vector <flower> v1,string comp){
	double H=0.0;
	double REM=0.0;
	double IG=0.0;

	//v1�N���������X�Aindex���ܦ���bound�����Ƕ��X

	vector<flower> small,big;

	double count1,count2,count3;

	for(int i=0;i<v1.size();i++){

		if(comp == "se_length"){
			if(v1[i].se_length < bound ) {
				small.push_back(v1[i]);
			}
			else if(v1[i].se_length >= bound){
				big.push_back(v1[i]);
			}
		}
		else if(comp == "se_width"){
			if(v1[i].se_width < bound ) {
				small.push_back(v1[i]);
			}
			else if(v1[i].se_width >= bound){
				big.push_back(v1[i]);
			}
		}
		else if(comp=="pe_length"){
			if(v1[i].pe_length < bound ) {
				small.push_back(v1[i]);
			}
			else if( v1[i].pe_length >= bound){
				big.push_back(v1[i]);
			}

		}
		else if(comp=="pe_width"){
			if(v1[i].pe_width < bound ) {
				small.push_back(v1[i]);
			}
			else if( v1[i].pe_width >= bound){
				big.push_back(v1[i]);
			}

		}

	}

	/*for(int i=0;i<small.size();i++)
		cout<<small[i].se_length<<" "<<small[i].se_width<<" "<<small[i].pe_length<<" "<<small[i].pe_width<<"\n";
	system("pause");
	cout<<"\n"<<bound<<"\n";
	for(int i=0;i<big.size();i++)
		cout<<big[i].se_length<<" "<<big[i].se_width<<" "<<big[i].pe_length<<" "<<big[i].pe_width<<"\n";
	system("pause");*/

	count1=0.0;
	count2=0.0;
	count3=0.0;
	for(int i=0;i<small.size();i++){
		if(small[i].kind == "Iris-setosa")
			count1 =count1 + 1.0;
		else if(small[i].kind == "Iris-versicolor")
			count2=count2 + 1.0;
		else if(small[i].kind =="Iris-virginica")
			count3=count3+1.0;
	}

	for(int i=0;i<big.size();i++){
		if(big[i].kind == "Iris-setosa")
			count1 =count1 + 1.0;
		else if(big[i].kind == "Iris-versicolor")
			count2=count2 + 1.0;
		else if(big[i].kind =="Iris-virginica")
			count3=count3+1.0;
	}
	double total=0.0;
	total=count1+count2+count3;
		if(count1==0.0) count1=total;
		if(count2==0.0) count2=total;
		if(count3==0.0) count3=total;
		if(total==0.0) H=0;
		else {
            H=-( (count1/total) * log2(count1/total) ) - ( (count2/total) * log2(count2/total) )  - ( (count3/total) * log2(count3/total) );
		}

	double count4,count5,count6,count7,count8,count9,count10,count11,count12,count13,count14,count15;
	count4=count5=count6=count7=count8=count9=count10=count11=count12=count13=count14=count15=0.0;
	for(int i=0;i<small.size();i++){
		if(small[i].kind=="Iris-setosa")
			count4=count4+1.0;
		else if(small[i].kind=="Iris-versicolor")
			count5=count5+1.0;
		else
			count6=count6+1.0;
	}
	for(int i=0;i<big.size();i++){
		if(big[i].kind=="Iris-setosa")
			count7=count7+1.0;
		else if(big[i].kind=="Iris-versicolor")
			count8=count8+1.0;
		else
			count9=count9+1.0;
	}
	double total2=0.0;
	double total3=0.0;
	total2= count4+count5+count6;
	total3=count7+count8+count9;
	double REM_s=0.0;
	double REM_b=0.0;
	double s=small.size();
	double b=big.size();
	double su=s+b;
	if(count4==0) count4=total2;
	if(count5==0) count5=total2;
	if(count6==0) count6=total2;
	if(count7==0) count7=total3;
	if(count8==0) count8=total3;
	if(count9==0) count9=total3;
	//cout<<"count4 "<<count4<<" "<<"count5 "<<count5<<" "<<"count6"<<count6<<" "<<"total2 "<<total2<<"\n";
	//cout<<"count7 "<<count7<<" "<<"count8 "<<count8<<" "<<"count9 "<<count9<<" "<<"total3 "<<total3<<"\n";
	if(total2==0) REM_s=0;
	else{
        REM_s=( (s/su) *( -( (count4/total2) *  log2(count4/total2) )  - ( (count5/total2) *  log2(count5/total2)  ) - ( (count6/total2) *  log2(count6/total2)  ) )   );
	}
    if(total3==0) REM_b=0;
    else
    {
        REM_b=( (b/su) * ( -( (count7/total3) *  log2(count7/total3) )  - ( (count8/total3) *  log2(count8/total3)  ) - ( (count9/total3) *  log2(count9/total3)  ) )   );
    }

	/*cout<<REM_s<<" ";
	cout<<REM_b<<"\n";
	system("pause");*/
	REM=REM_s+REM_b;
	IG=H-REM;
	return IG;


}
Tree* de_tree=new Tree();
node* current=de_tree->root;
void ID3(vector <flower> cal){


	if(cal.size()==1 || cal.size()==0) {
		return;
	}
	int check=1;
	for(int i=0;i< (cal.size()-1) ; i++){
		if(cal[i].kind != cal[i+1].kind) check=0;
	}
	if(check==1){
		return ;
	}

	vector <double> bound;
	vector <double> inform;
	inform.clear();
	bound.clear();
	double tf;
	double bound_gain[4]={0};
	int index[4]={0};
	double bound_num[4]={0};
	string comp;
	for(int i=1;i<=4;i++){
		countbound(cal,bound,i); //bound���ɰ����w�g�s�F��ɼƦr ,i�O�Ψӻ��έ��Ӫ�ä���׺�
		/*for(int j=0;j<bound.size();j++){
			cout<<"bound "<<bound[j]<<"\n";
		}*/
		if(i==1) comp="se_length";
		else if(i==2) comp="se_width";
		else if(i==3) comp="pe_length";
		else if(i==4) comp="pe_width";
		for(int j=0;j<bound.size();j++){
			tf=INFO(bound[j],cal,comp);
			inform.push_back(tf);
			//cout<<"tf "<<tf<<"\n";
	//	cout<<tf<<"\n";
		}
		double in_max=inform[inform.size()-1 ];
		bound_gain[i-1]=in_max;
		bound_num[i-1] = bound[inform.size()-1];
        /*for(int i=0;i<inform.size();i++)
        {
            cout<<"INFORM: "<<inform[i]<<" ";
            cout<<"Bound: "<<bound[i]<<"\n"  ;
        }*/


        //cout<<"IN MAX="<<in_max<<"\n";

		for(int j=0;j< (inform.size() -1 );j++){
			if(inform[j] > in_max ){
				bound_gain[i-1] = inform[j];//bound_gain�s�̤j��IG
				bound_num[i-1]= bound [j];
				in_max = inform[j];
			}

		}

		//cout<<"fnc boga "<<bound_gain[i-1]<<"\n";
//cout<<"fnc bonu "<<bound_num[i-1]<<"\n";
		inform.clear();
		bound.clear();
		//system("pause");

	}


	double best_info=bound_gain[3];
	double best_bound = bound_num[3];
//	cout<<bound_gain[3]<<"\n";
	int best_index=4;
	for(int i=0;i<3;i++){
		if(bound_gain[i] > best_info){
			best_info=bound_gain[i];
			best_bound = bound_num[i];
			best_index = i+1;  //�N���β�i��feacturs������INFO�̤j
			best_info = bound_gain[i];
		}
	}
	/*for(int i=0;i<4;i++)
		cout<<"bound_gain"<<bound_gain[i]<<"\n";
	system("pause");*/



	vector <flower> small;
	vector <flower> big;
	for(int j=0;j<cal.size();j++){
		if(best_index==1 && cal[j].se_length < best_bound){
			small.push_back(cal[j]);
		}
		else if(best_index==1 && cal[j].se_length >= best_bound){
			big.push_back(cal[j]);
		}
		else 	if(best_index==2 && cal[j].se_width < best_bound){
			small.push_back(cal[j]);
		}
		else 	if(best_index==2 && cal[j].se_width >= best_bound){
			big.push_back(cal[j]);
		}
		else 	if(best_index==3 && cal[j].pe_length < best_bound){
			small.push_back(cal[j]);
		}
		else 	if(best_index==3 && cal[j].pe_length >= best_bound){
			big.push_back(cal[j]);
		}
		else 	if(best_index==4 && cal[j].pe_width < best_bound){
			small.push_back(cal[j]);
		}
		else 	if(best_index==4 && cal[j].pe_width >= best_bound){
			big.push_back(cal[j]);
		}

	}
	//cout<<"fuck"<<"\n";
	/*cout<<"best info "<<best_info<<"\n";
	cout<<"best bound "<<best_bound<<"\n";
	cout<<"best index "<<best_index<<"\n";
	cout<<"\n";
	system("pause");*/

	node* root=new node(cal);
	node* l=new node(small);
	node* r=new node(big);
	if(current){
		de_tree->Insert(current,l,r,best_index,best_bound);
	}
	else
	{
		de_tree->Insert(root);
		current = de_tree->root;
		de_tree->Insert(current,l,r,best_index,best_bound);

	}





	/*for(int i=0;i<small.size();i++)
		cout<<small[i].se_length<<" "<<small[i].se_width<<" "<<small[i].pe_length<<" "<<small[i].pe_width<<" "<<small[i].kind<<" "<<small.size()<<"\n";
			for(int i=0;i<big.size();i++)
		cout<<big[i].se_length<<" "<<big[i].se_width<<" "<<big[i].pe_length<<" "<<big[i].pe_width<<" "<<big[i].kind<<" "<<big.size()<<"\n";
	system("pause");
	cout<<"left  "<<small.size()<<" "<<"right "<<big.size()<<"\n";
	system("pause");*/
    current=current->left;
	ID3(small);
	current=current->parent;
	current=current->right;
	ID3(big);
	current=current->parent;

	// ��������




}

void test(vector <flower> t_d,int &times){
    for(int i=0;i<t_d.size();i++){
        node* t=de_tree->root;
        while(t != NULL){
                if(t->left==NULL && t->right==NULL){
                    string r =t->set[0].kind;
                    
                     if(r=="Iris-setosa") pr_a=pr_a+1.0;
            else if(r=="Iris-versicolor") pr_b=pr_b+1.0;
            else if(r=="Iris-virginica") pr_c=pr_c+1.0;
            if(r=="Iris-setosa" && t_d[i].kind=="Iris-setosa") good_a=good_a+1.0;
            else if(r=="Iris-versicolor" && t_d[i].kind=="Iris-versicolor") good_b = good_b+1.0;
            else if(r=="Iris-virginica" && t_d[i].kind=="Iris-virginica") good_c= good_c+1.0;
            
                    //cout<<"prediction: "<<r<<", answer: "<<t_d[i].kind<<endl;
                    break;
                }
               else if(t->features=="se_length"){ // sl
                        //cout<<"1"<<endl;
                        if(t_d[i].se_length >= t->bound){
                            t=t->right;
                        }
                        else{
                            t=t->left;
                        }
                    }
                    else if(t->features=="se_width"){ // sw
                        //cout<<"2"<<endl;
                        if(t_d[i].se_width >= t->bound){
                            t=t->right;
                        }
                        else{
                            t=t->left;
                        }
                    }
                    else if(t->features =="pe_length"){ // pl
                        //cout<<"3"<<endl;
                        if(t_d[i].pe_length >= t->bound){
                            t=t->right;
                        }
                        else{
                            t=t->left;
                        }
                    }
                    else if(t->features == "pe_width"){ // pw
                        //cout<<"4"<<endl;
                        if(t_d[i].pe_width >= t->bound){
                            t=t->right;
                        }
                        else{
                            t=t->left;
                        }
                    }
            }
    }
    
    times = times +1;
t_a.push_back( (good_a+good_b+good_c)/30.0 );
c_a.push_back( (good_a)/( re_a ) );
p_a.push_back( (good_a)/( pr_a) );
c_b.push_back( (good_b)/( re_b ) );
p_b.push_back( (good_b)/( pr_b) );
c_c.push_back( (good_c)/( re_c ) );
p_c.push_back( (good_c)/( pr_c) );
   
   if(times==5){
        double temp=0.0;
        for(int i=0;i<t_a.size();i++){
            temp=temp+t_a[i];
        }
        cout<<(temp/5.0)<<"\n";
        temp=0.0;
        for(int i=0;i<p_a.size();i++){
            temp =temp+p_a[i];
        }
        cout<<(temp/5.0)<<" ";
        temp =0.0;
        for(int i=0;i<c_a.size();i++){
            temp= temp+c_a[i];
        }
        cout<<(temp/5.0)<<" ";
		cout<<"\n";
         temp=0.0;
        for(int i=0;i<p_b.size();i++){
            temp =temp+p_b[i];
        }
        cout<<(temp/5.0)<<" ";
        temp =0.0;
        for(int i=0;i<c_b.size();i++){
            temp= temp+c_b[i];
        }
        cout<<(temp/5.0)<<" ";
        cout<<"\n";

         temp=0.0;
        for(int i=0;i<p_c.size();i++){
            temp =temp+p_c[i];
        }
        cout<<(temp/5.0)<<" ";
        temp =0.0;
        for(int i=0;i<c_c.size();i++){
            temp= temp+c_c[i];
        }
        cout<<(temp/5.0)<<" ";
        temp=0.0;
		cout<<"\n";
}

    
    
    
pr_a=0.0;
pr_b=0.0;
pr_c=0.0;
good_a=0.0;
good_b=0.0;
good_c=0.0;
re_a=0.0;
re_b=0.0;
re_c=0.0;

}

int main(){
	ifstream infile("data.txt");
	vector<flower> cal;
	c_a.clear();
	c_b.clear();
	c_c.clear();
	p_a.clear();
	p_b.clear();
	p_c.clear();
	t_a.clear();
	
	cal.clear();
	cal.resize(150);
	int times=0;
	for(int i=0;i<150;i++){
		string input;
		stringstream s;
		char comma;
		getline(infile,input);
		s<<input;
		s>>cal[i].se_length;
		s>>comma;
		s>>cal[i].se_width;
		s>>comma;
		s>>cal[i].pe_length;
		s>>comma;
		s>>cal[i].pe_width;
		s>>comma;
		s>>cal[i].kind;
		//cout<<cal[i].se_length<<" "<<cal[i].se_length<<" "<<cal[i].pe_length<<" "<<cal[i].pe_width<<" "<<cal[i].kind;
		//cout<<"\n";
	}
	infile.close();
	srand(time(NULL));
	for(int i=0;i<cal.size();i++){
		cal[i].order=( rand() % 1000000000);
	}
	sort(cal.begin(),cal.end(),compare);
	vector<flower> train_data;
	vector<flower> test_data;
	for(int  i=1;i<=5;i++){
		if(i==1){
			for(int j=0;j<120;j++)
				train_data.push_back(cal[j] );
			for(int j=120;j<150;j++)
				test_data.push_back( cal[j] );

		}
		else if(i==2){
			for(int j=30;j<150;j++)
				train_data.push_back(cal[j] );
			for(int j=0;j<30;j++)
				test_data.push_back( cal[j] );

		}
		else	if(i==3){
			for(int j=0;j<30;j++)
				train_data.push_back(cal[j] );
			for(int j=30;j<60;j++)
				test_data.push_back( cal[j] );
			for(int j=60;j<150;j++)
				train_data.push_back(cal[j] );

		}

		else if(i==4){
			for(int j=0;j<60;j++)
				train_data.push_back(cal[j] );
			for(int j=60;j<90;j++)
				test_data.push_back( cal[j] );
			for(int j=90;j<150;j++)
				train_data.push_back(cal[j] );

		}
		else if(i==5){
			for(int j=0;j<90;j++)
				train_data.push_back(cal[j] );
			for(int j=90;j<120;j++)
				test_data.push_back( cal[j] );
			for(int j=120;j<150;j++)
				train_data.push_back( cal[j] );

		}
		
		for(int j=0;j<30;j++){
		if(test_data[j].kind=="Iris-setosa") re_a=re_a+1.0;
		else if(test_data[j].kind=="Iris-versicolor") re_b=re_b+1.0;
		else if(test_data[j].kind == "Iris-virginica") re_c=re_c+1.0;
		}
		ID3(train_data);
		test(test_data,times);
		train_data.clear();
		//cal.clear();
		test_data.clear();
		current = NULL;

	}
    cal.clear();
	c_a.clear();
	c_b.clear();
	c_c.clear();
	p_a.clear();
	p_b.clear();
	p_c.clear();
	t_a.clear();
	

	return 0;


}
