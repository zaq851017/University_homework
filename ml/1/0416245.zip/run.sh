#!/bin/bash
g++ 0416245_hw1.cpp -o fout
./fout
exit 0
