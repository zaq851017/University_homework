# -*- coding: utf-8 -*-
"""
Created on Mon Nov 27 20:58:28 2017

@author: hong
"""
import sys
check=[]
class d_tree(object):
    def __init__(self):
        self.point = 0.0 #dat a point
        self.split = 0
        self.left_child = None
        self.right_child = None
        self.knn_traversed = False
        self.list_leaf=[None]*12
        self.dis = -1.0
        

def split_tree(list_u,index):
    list_left=[[None]*13 for i in range(1)]
    list_right=[[None]*13 for i in range(1)]
    del list_left[0]
    del list_right[0]
    list_u.sort(key=lambda x:x[index])
    a=0 # a is an integer
    a = int(len(list_u)/2)
    
    
    for i in range(0,a): # put list[0]~list[n-1]
        list_left.append(list_u[i])
    for i in range(a+1,len(list_u)):
        list_right.append(list_u[i])
    root = d_tree()
    root.split=index
    root.point=list_u[a][index]
    root.list_leaf =list_u[a]
    # split save what dimesion to split
    # point is the value which to split
    # list_leaf represent the node [12] data which has been splited
    root.left = build_tree (list_left)
    root.right = build_tree (list_right)
    return root # finally root
            

def build_tree (list_u):
    
    if len (list_u) ==1:
        root = d_tree();
        root.list_leaf=list_u[0]
        root.left=None
        root.right=None
        return root
    elif len(list_u)==0:
        return None
    #var_list = [] # list
    max_var = 0 # find max var to split
    index = 0
    
    for i in range(2,11): #cal index=2~ 11 who var is big
        sum1 = 0.0
        total1 =0.0
        avg1 = 0.0
        
        for j in range(0,len(list_u)): # general = 300
            sum1 +=float(list_u[j][i])
            
        avg1 = sum1/len(list_u)
        
        for j in range(0,len(list_u)):
            temp=float(list_u[j][i])-avg1
            temp *= temp
            total1 += temp
            
        total1 /= len(list_u)
        
        if(i==2): #secnod let it be max temperal
            max_var=total1;
            index = 2;
        else:
            if(total1 > max_var):
               max_var=total1;
               index = i; 
      # cal max var and find the best index to split
    root1=split_tree(list_u,index)
    return root1 
         


        


   
def  walk(root1):
     check.append(int(root1.list_leaf[0]))
     #print(root1.split)
     if root1.left==None and root1.right==None:
        return 
     if root1.left!=None:
        walk(root1.left)
     if root1.right!=None:
        walk(root1.right)
     return 
 
    
def f_distance(point1,point2):
    f_dis=0.0
    for m in range(2,11):
        f_dis+=(float(point1[m])-float(point2[m]))*(float(point1[m])-float(point2[m]))
    return f_dis
    

def var(list_u):
    max_var = 0
    index = 0
    
    for i in range(2,11): #cal index=2~ 11 who var is big
        sum1 = 0.0
        total1 =0.0
        avg1 = 0.0
        
        for j in range(0,len(list_u)): # general = 300
            sum1 +=float(list_u[j][i])
            
        avg1 = sum1/len(list_u)
        
        for j in range(0,len(list_u)):
            temp=float(list_u[j][i])-avg1
            temp *= temp
            total1 += temp
            
        total1 /= len(list_u)
        
        if(i==2): #secnod let it be max temperal
            index = 2;
        else:
            if(total1 > max_var):
               index = i;
    return index    
    

def KNN (func_root , q_point): #funcroot is address
    # root:KDTree的樹根 query:查詢點 return:返回距離data最近的點NN
    nearest = func_root #just want the data in it
    #print(nearest.list_leaf)
    #print(q_point)
    min_dist = f_distance (q_point,nearest.list_leaf)
    traversed_point = []
    cur_point = func_root  #has to be the all node
    
    
    while cur_point:
        traversed_point.append(cur_point)
        cur_dist = f_distance(q_point,cur_point.list_leaf)
        if cur_dist < min_dist and cur_point.knn_traversed == False:
            nearest = cur_point
            min_dist = cur_dist

        cur_split = cur_point.split
        
        if(q_point[cur_split] < cur_point.list_leaf[cur_split]):
            cur_point = cur_point.left_child
         
        else:
            cur_point = cur_point.right_child
        
            
    #backtrace
    while traversed_point:
        back_point = traversed_point.pop()  # 一旦traverse過就把點拿出來
        cur_split = back_point.split
        if abs(float( q_point[cur_split]) - float( back_point.list_leaf[cur_split] ) ) < min_dist:
            if( q_point[cur_split] < back_point.list_leaf[cur_split]): #the other side
                cur_point = back_point.right_child
            else:
                cur_point = back_point.left_child

            if cur_point: #is the retraversed one
                traversed_point.append(cur_point)
                back_trace_distance = f_distance(q_point,cur_point.point)
                if back_trace_distance < min_dist and cur_point.knn_traversed == False:
                    nearest = cur_point
                    min_dist = back_trace_distance

    nearest.knn_traversed = True
    nearest_id = nearest.list_leaf[0]
    nearest_class = nearest.list_leaf[11]
    return nearest_id,nearest_class
   



def tree_traverse_check(current_kd_node,cnt):
    current_kd_node.knn_traversed = False
   # print("traversed ID ",current_kd_node.point[0])
    if current_kd_node.left_child:
        tree_traverse_check(current_kd_node.left_child,cnt+1)
    if current_kd_node.right_child:
        tree_traverse_check(current_kd_node.right_child,cnt+1)


def f_out(f_root,f_data,f_test,out_file):
    validation_set = []
    for i in range(0,36):
        validation_set.append(data[i])
    knn_result_hash = {'cp':0,'im':0,'pp':0,'imU':0,'om':0,'omL':0,'imL':0,'imS':0}
    classname_set = ['cp','im','pp','imU','om','omL','imL','imS']
    first_three_output = [[] for i in range(3)]
    for knn_query in [1,5,10,100]:
        first_three_output = [[] for i in range(3)]
        for query_index in range(0,36):
            query_point = validation_set[query_index] #take the point for querying
            for search_hash in range(len(classname_set)): #clear the hash map for the query from each point for voting
                knn_result_hash[classname_set[search_hash]] = 0
            
            tree_traverse_check(f_root,0) #clear all traversed mark to false first,which symbolized non traversed
            
            for individual_knn_query in range(0,knn_query):
                NN,predicted_class = KNN(f_root , query_point)
                knn_result_hash[predicted_class] += 1
                if(query_index >=0 and query_index<3): #outputresult
                    first_three_output[query_index].append(NN)
            max_voted_class = 0
            for search_hash in range(len(classname_set)): #voting for the best result
                if knn_result_hash[classname_set[search_hash]] > max_voted_class:
                    max_voted_class = knn_result_hash[classname_set[search_hash]]
            #print("Original ",original_class," predicted class",final_predicted_class)
           
        
        
    
    test_data=[]
    train_data=[]
    c_train=[]
    for i in range(0,36):
        test_data.append(f_test[i])
    for i in range(0,300):
        train_data.append(f_data[i])
    for i in range(0,300):
        c_train.append(f_data[i])
    
    
    
    for k_n in [1,5,10,100]:
        pre_dict=0
        for p_n in range(0,36):
            for point in range(0,300):
                train_data[point][12] =f_distance( test_data[p_n],train_data[point])
                 #print(train_data[point][12])
            #list_u.sort(key=lambda x:x[index])
            train_data.sort(key=lambda x:x[12])
            if(k_n==1):
                    if(test_data[p_n][11] == train_data[0][11]):
                        pre_dict = pre_dict + 1
            else:
                cp=0
                im=0
                pp=0
                imU=0
                om=0
                oml=0
                inL=0
                imS=0
                for i in range(0,k_n):
                    if(train_data[i][11]=="cp"):
                        cp=cp+1
                    elif(train_data[i][11]=="im"):
                        im=im+1
                    elif(train_data[i][11]=="pp"):
                        pp=pp+1
                    elif(train_data[i][11]=="imU"):
                        imU=imU+1
                    elif(train_data[i][11]=="om"):
                        om=om+1
                    elif(train_data[i][11]=="oml"):
                        oml=oml+1
                    elif(train_data[i][11]=="inL"):
                        inL=inL+1
                    elif(train_data[i][11]=="imS"):
                        imS=imS+1
                list=[cp,im,pp,imU,om,oml,inL,imS]
                list.sort()
                if(cp==list[7]):
                    if(test_data[p_n][11] == "cp"):
                        pre_dict=pre_dict+1
                if(im==list[7]):
                    if(test_data[p_n][11] == "im"):
                        pre_dict=pre_dict+1
                if(pp==list[7]):
                    if(test_data[p_n][11] == "pp"):
                        pre_dict=pre_dict+1
                if(imU==list[7]):
                    if(test_data[p_n][11] == "imU"):
                        pre_dict=pre_dict+1
                if(om==list[7]):
                    if(test_data[p_n][11] == "om"):
                        pre_dict=pre_dict+1
                if(oml==list[7]):
                    if(test_data[p_n][11] == "oml"):
                        pre_dict=pre_dict+1
                if(inL==list[7]):
                    if(test_data[p_n][11] == "inL"):
                        pre_dict=pre_dict+1
                if(imS==list[7]):
                    if(test_data[p_n][11] == "imS"):
                        pre_dict=pre_dict+1
            if(p_n >= 0 and p_n <3):
                abc=[]
                bcd=[]
                for no in range(0,k_n):
                    num2 = train_data[no]
                    abc.append(num2)
                for no in range(0,k_n):
                    num=abc[no][0]
                    bcd.append(int(num))
                bcd.sort()
                for no in range(0,k_n):
                    print(train_data[no][0],end=" ")
                    out_file.write(train_data[no][0])
                    out_file.write(" ")				
                print("\n")
                out_file.write("\n")
            for yes in range(0,300):
                train_data[yes][12]=-1
        print("KNN accuracy: %f" % (float(pre_dict/36)))
        out_file.write("KNN accuracy: %f\n" % (float(pre_dict/36)))
        print("\n")
        out_file.write("\n")		
            
    

in_file=open(sys.argv[1],"r")
test_file=open(sys.argv[2],"r")
out_file=open("output.txt","w")
data=[[None]*13 for i in range(1)]# 2-dimension list
o_data=[[None]*13 for i in range(1)]
test_data =[[None]*13 for i in range(1)]
del o_data[0]
del data[0]
del test_data[0]
for line in in_file.readlines(): 
    data.append(line.strip().split(','))
    o_data.append(line.strip().split(','))
del data[0]
del o_data[0]
    
for i in range(0,300):
    data[i].append(-1)
    o_data[i].append(-1)
    
for line in test_file.readlines():
    test_data.append(line.strip().split(','))
del test_data[0]

for i in range(0,36):
    test_data[i].append(-1)


    
    #print(data[299])
in_file.close()
test_file.close()
    # file is read to list1[0] ~ list1[299]
index= var(data)
root = build_tree(data)
f_out(root ,o_data,test_data,out_file)
out_file.close()