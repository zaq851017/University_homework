# -*- coding: utf-8 -*-
"""
Created on Fri Dec 22 21:11:50 2017

@author: hong
"""
import random
import numpy
from sklearn import tree
from sklearn import metrics
from sklearn import neighbors
from sklearn.naive_bayes import MultinomialNB   
""" main """
in_file=open("1.txt","r")
data = [[None]*5 for i in range(1)]
del data[0]
for line in in_file.readlines(): 
    data.append(line.strip().split(','))
    
for line in range(0,150):
    if(data[line][4]=="Iris-setosa") :data[line][4]=0
    elif(data[line][4]=="Iris-versicolor"):data[line][4]=1
    elif(data[line][4]=="Iris-virginica"):data[line][4]=2
    
for line in range(0,150):
    data[line][0]= float(data[line][0])
    data[line][1]=float(data[line][1])
    data[line][2]=float(data[line][2])
    data[line][3]=float(data[line][3])



test_data = [[None]*5 for i in range(1)]
train_data = [[None]*5 for i in range(1)]
del test_data[0]
del train_data[0]
random.shuffle(data)
for i in range(0,105):
    train_data.append(data[i])
for i in range(105,150):
    test_data.append(data[i])
train_x = [[None]*4 for i in range(1)]
train_y= [[None]*1 for i in range(1)]
test_x = [[None]*4 for i in range(1)]
test_y= [[None]*1 for i in range(1)]
del train_x[0]
del train_y[0]
del test_x[0]
del test_y[0]

for i in range(0,105):
    train_y.append(train_data[i][4])
for i in range(0,105):
    del train_data[i][4]
for i in range(0,105):
    train_x.append(train_data[i])

for i in range(0,45):
    test_y.append(test_data[i][4])
for i in range(0,45):
    del test_data[i][4]
for i in range(0,45):
    test_x.append(test_data[i])

n_trainx= numpy.array(train_x)
n_trainy = numpy.array(train_y)
n_testx = numpy.array(test_x)
n_testy = numpy.array(test_y)

clf = tree.DecisionTreeClassifier()
iris_clf = clf.fit(n_trainx, n_trainy)
d_test_y_predicted = iris_clf.predict(n_testx)
accuracy = metrics.accuracy_score(n_testy, d_test_y_predicted)
print("Use decision tree accuracy is:",end=" ")
print(accuracy,end="\n")

"""KNN method"""

for i in range(5,11):
    
    k_clf = neighbors.KNeighborsClassifier(n_neighbors = i)
    k_iris_clf = k_clf.fit(n_trainx, n_trainy)
    k_test_y_predicted = k_iris_clf.predict(n_testx)
    k_accuracy = metrics.accuracy_score(n_testy, k_test_y_predicted)
    
    print("K=",end=" ")
    print(i,end=" ")
    print("Use KNN tree accuracy is:",end=" ")
    print(k_accuracy,end="\n")
    
"""naive_bayes"""
n_clf = MultinomialNB ()
n_test_y_predicted = n_clf.fit(n_trainx, n_trainy).predict(n_testx)
#n_test_y_predicted = n_clf.fit(n_trainx, n_trainy).predict(n_testx)
n_accuracy = metrics.accuracy_score(n_testy, n_test_y_predicted)
print("Use naive_bayes tree accuracy is:",end=" ")
print(n_accuracy,end="\n")



    


    
    



