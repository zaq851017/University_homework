# -*- coding: utf-8 -*-
"""
Created on Sat Dec 23 18:00:22 2017

@author: hong
"""

"""main"""
import random
import numpy
from sklearn import tree
from sklearn import metrics
from sklearn import neighbors
from sklearn.naive_bayes import MultinomialNB  

in_file=open("2.csv","r")
data=[[None]*13 for i in range(1)]
del data[0]
for line in in_file.readlines(): 
	data.append(line.strip().split(','))
del data[0]

for i in range(0,517):
    data[i][0]= float(data[i][0])
    data[i][1]= float(data[i][1])
    if(data[i][2]=="jan"):data[i][2]=1
    elif(data[i][2]=="feb"):data[i][2]=2
    elif(data[i][2]=="mar"):data[i][2]=3
    elif(data[i][2]=="apr"):data[i][2]=4
    elif(data[i][2]=="may"):data[i][2]=5
    elif(data[i][2]=="jun"):data[i][2]=6
    elif(data[i][2]=="jul"):data[i][2]=7
    elif(data[i][2]=="aug"):data[i][2]=8
    elif(data[i][2]=="sep"):data[i][2]=9
    elif(data[i][2]=="oct"):data[i][2]=10
    elif(data[i][2]=="nov"):data[i][2]=11
    elif(data[i][2]=="dec"):data[i][2]=12
    if(data[i][3]=="mon"):data[i][3]=1
    elif(data[i][3]=="tue"):data[i][3]=2
    elif(data[i][3]=="wed"):data[i][3]=3
    elif(data[i][3]=="thu"):data[i][3]=4
    elif(data[i][3]=="fri"):data[i][3]=5
    elif(data[i][3]=="sat"):data[i][3]=6
    elif(data[i][3]=="sun"):data[i][3]=7
    data[i][4]=float(data[i][4])
    data[i][5]=float(data[i][5])
    data[i][6]=float(data[i][6])
    data[i][7]=float(data[i][7])
    data[i][8]=float(data[i][8])
    data[i][9]=float(data[i][9])
    data[i][10]=float(data[i][10])
    data[i][11]=float(data[i][11])
    data[i][12]= float(data[i][12])
    if(data[i][12]==0.0):data[i][12]=0
    elif(data[i][12] >0.0 and data[i][12]<=1.0):data[i][12]=1
    elif(data[i][12] >1.0 and data[i][12] <=10.0):data[i][12]=2
    elif(data[i][12] >10.0 and data[i][12] <= 100.0):data[i][12]=3
    elif(data[i][12] > 100.0 and data[i][12] <= 1000.0):data[i][12]=4
    elif(data[i][12] > 1000.0):data[i][12]=5
   
test_data = [[None]*13 for i in range(1)]
train_data = [[None]*13 for i in range(1)]
del test_data[0]
del train_data[0]
random.shuffle(data)
for i in range(0,362):
    train_data.append(data[i])
for i in range(362,517):
    test_data.append(data[i])

train_x = [[None]*12 for i in range(1)]
train_y= [[None]*1 for i in range(1)]
test_x = [[None]*12 for i in range(1)]
test_y= [[None]*1 for i in range(1)]
del train_x[0]
del train_y[0]
del test_x[0]
del test_y[0]
for i in range(0,362):
    train_y.append(train_data[i][12])
for i in range(0,362):
    del train_data[i][12]
for i in range(0,362):
    train_x.append(train_data[i])

for i in range(0,155):
    test_y.append(test_data[i][12])
for i in range(0,155):
    del test_data[i][12]
for i in range(0,155):
    test_x.append(test_data[i])

n_trainx= numpy.array(train_x)
n_trainy = numpy.array(train_y)
n_testx = numpy.array(test_x)
n_testy = numpy.array(test_y)

clf = tree.DecisionTreeClassifier()
iris_clf = clf.fit(n_trainx, n_trainy)
d_test_y_predicted = iris_clf.predict(n_testx)
accuracy = metrics.accuracy_score(n_testy, d_test_y_predicted)
print("Use decision tree accuracy is:",end=" ")
print(accuracy,end="\n")

"""KNN method"""

for i in range(30,36):
    
    k_clf = neighbors.KNeighborsClassifier(n_neighbors = i)
    k_iris_clf = k_clf.fit(n_trainx, n_trainy)
    k_test_y_predicted = k_iris_clf.predict(n_testx)
    k_accuracy = metrics.accuracy_score(n_testy, k_test_y_predicted)
    
    print("K=",end=" ")
    print(i,end=" ")
    print("Use KNN tree accuracy is:",end=" ")
    print(k_accuracy,end="\n")
    
"""naive_bayes"""
n_clf = MultinomialNB()
n_test_y_predicted = n_clf.fit(n_trainx, n_trainy).predict(n_testx)
#n_test_y_predicted = n_clf.fit(n_trainx, n_trainy).predict(n_testx)
n_accuracy = metrics.accuracy_score(n_testy, n_test_y_predicted)
print("Use naive_bayes tree accuracy is:",end=" ")
print(n_accuracy,end="\n")

